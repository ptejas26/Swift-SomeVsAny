import UIKit

protocol Flyable {
    var canFly: Bool { get }
    // Distance in Miles
    var distance: Double { get }
}

func anyFly(_ flyingObject: any Flyable) {
    print("any Flyable")
    print(flyingObject.canFly)
    print(flyingObject.distance)
}

func someFly(_ flyingObject: some Flyable) {
    print("some Flyable")
    print(flyingObject.canFly)
    print(flyingObject.distance)
}

class Aeroplane: Flyable {
    var canFly: Bool {
        return true
    }

    // Distance in Miles
    var distance: Double {
        return 80000.0
    }
}

class Bird: Flyable {
    var canFly: Bool {
        return true
    }

    var distance: Double {
        return 200
    }
}

someFly(Aeroplane())
someFly(Bird())
print("------------")
anyFly(Aeroplane())
anyFly(Bird())

print("------------")
func returnAnyFlyable() -> any Flyable {
    return Bool.random() ? Aeroplane() : Bird()
}

func returnSomeFlyable() -> some Flyable {
    return Aeroplane()
}

let anyFlyable = returnAnyFlyable()
print(anyFlyable.distance) // This could be from either Aeroplane or Bird, decided at runtime.

let someFlyable = returnSomeFlyable()
print(someFlyable.distance) // This will always be from Aeroplane, known at compile-time.
